#include <iostream>
#include <map>
#include <string>
#include "WordMap.h"

using namespace std;
using namespace std::chrono;

WordMap::WordMap()
{
}

WordMap::~WordMap()
{
}

map<string, Word>& WordMap::get_data() { return data; }

int WordMap::get_count(const string text) const
{
	Word co(text);
    map<string, Word>::const_iterator it = data.find(text);
    if(it==data.end())
    return -1;
    
}

void WordMap::insert(const string text)
{
  	std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();

	Word co(text);
    pair<map<string, Word>::iterator,int> cm = data.insert(make_pair(text,co));
    
    if(cm.second==0){
    cm.first->second.increment_count();
    }
       
    std::chrono::steady_clock::time_point end= std::chrono::steady_clock::now();
    long duration=std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count();
    increment_elapsed_time(duration);
}

map<string, Word>::iterator WordMap::search(const string text)
{  	Word co(text);
  	std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();

    map<string, Word>::iterator it=data.find(text);
    
    std::chrono::steady_clock::time_point end= std::chrono::steady_clock::now();
    long duration=std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count();
    increment_elapsed_time(duration);
    return it;
}

#include "WordMap.h"
