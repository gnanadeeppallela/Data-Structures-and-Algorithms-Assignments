#include <iostream>
#include <vector>
#include <string>
#include "WordVector.h"
#include <iterator>
#include <map>

using namespace std;
using namespace std::chrono;

WordVector::WordVector()
{
}

WordVector::~WordVector()
{
}

vector<Word>& WordVector::get_data() { return data; }

int WordVector::get_count(const string text)
{
    vector<Word>::iterator it;
	int a = find(text, 0, data.size()-1);
	if(a==-1)
	return -1;
	else
	return data[a].get_count();
}

void WordVector::insert(const string text)
{
	Word co(text);
    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();

        int a=find(text, 0, data.size());

        if (a==-1)
        {
            vector<Word>::iterator it = data.begin();
            auto cm=data.insert(it,co);
        }
        else
        {
            data[a].increment_count();
        }
    

	std::chrono::steady_clock::time_point end= std::chrono::steady_clock::now();
    long duration=std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count();
    increment_elapsed_time(duration);
}

vector<Word>::iterator WordVector::search(const string text)
{
    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    int a=find(text,0,data.size()-1);
    std::chrono::steady_clock::time_point end= std::chrono::steady_clock::now();
    long duration=std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count();
    increment_elapsed_time(duration);
    if(a==-1)
    return data.end();
    else
    return data.begin()+a;
}

int WordVector::find(const string text, int low, int high) const
{
   for (int i = low; i < high; i++){  
      if (data[i].get_text() == text)
         return i;
   }
   return -1;
}

#include "WordVector.h"
