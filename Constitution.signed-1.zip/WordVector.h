#ifndef WORDVECTOR_H_
#define WORDVECTOR_H_

/***** Modify this file as needed. *****/

#include <vector>
#include <ctime>
#include <chrono>
#include "TimedContainer.h"
#include "Word.h"

using namespace std;

class WordVector : public TimedContainer
{
public:
    WordVector();
    virtual ~WordVector();

    vector<Word>& get_data();
    int get_count(const string text);

    void insert(const string text);
    vector<Word>::iterator search(const string text);
    bool operator ==(const WordVector& other);
//private:
    vector<Word> data;

    int find(const string text, int low, int high) const;
};

#endif /* WORDVECTOR_H_ */
