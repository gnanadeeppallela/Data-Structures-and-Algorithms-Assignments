#include<iostream>
#include<vector>
using namespace std;

const int MAX_SIZE = 101;  // maximum size of the square matrix
const int MAX_START = 50;   // maximum starting number

char checkprime(int a);
void make_spiral(vector<vector<char> > &arr, int n, int start);
char print_spiral(vector<vector<char> > arr, int row, int column, int n);
void do_prime_spiral(const int n, const int start);

/**
 * The main: Generate and print spirals of various sizes.
 */
int main()
{
	do_prime_spiral(5, 1);
	do_prime_spiral(25, 11);
	do_prime_spiral(35, 0);
	do_prime_spiral(50, 31);
	do_prime_spiral(101, 41);
}

//The function to obtain size and start values
void do_prime_spiral(const int n, const int start)
{
	vector<vector<char> > arr;
	(arr).resize(n, std::vector<char>(n, '/'));

	cout << "Prime Spiral of size " << n << " starting at " << start << endl;

	//the size is odd
	if (n % 2 != 0 && start > 0 && start <= 50)
	{
		cout << endl;
		make_spiral((arr), n, start);
		for (int row = 0; row < n; row++)
		{
			for (int column = 0; column < n; column++)
			{
				print_spiral(arr, row, column, n);
				if (column == n - 1)
					cout << endl;
			}
		}
	}
	else if (start <= 0 || start > 50)
		cout << "***** Error: Starting value " << start << " < 1 or > 50"
				<< endl;
	//the size is even
	else
	{
		cout << "***** Error: Size " << n << " must be odd." << endl;
	}
	cout << endl;
}

//the function create the spiral
void make_spiral(vector<vector<char> > &arr, int n, int start)
{
	int last = start - 1 + n * n, times = n;
	int row, column, index = 0;

	//the size is greater than 1
	if (n > 1)
	{
		while (n > 0)
		{
			//bottom row
			row = n - 1;
			for (int column = n - 1; column >= index; column--)
			{
				arr[row][column] = checkprime(last--);
			}

			//left column
			column = index;
			for (int row = n - 2; row >= index; row--)
			{
				arr[row][column] = checkprime(last--);
			}

			//top row
			row = index;
			for (int column = index + 1; column <= n - 1; column++)
			{
				arr[row][column] = checkprime(last--);
			}

			//right column
			column = n - 1;
			for (int row = index + 1; row <= n - 2; row++)
			{
				arr[row][column] = checkprime(last--);
			}
			n--;
			index++;
		}

	}
	//size is 1
	else
		arr[n - 1][n - 1] = 1;
}

//check prime or not
char checkprime(int a)
{
	bool prime;
	for (int i = 2; i <= MAX_SIZE; ++i)
	{
		//return '.' when composite
		if (a % i == 0 and i != a || a == 1)
		{
			return '.';
			break;
		}

	}
	//return '#' when prime
	return '#';
}

//print the number without tab
char print_spiral(vector<vector<char> > arr, int row, int column, int n)
{
	cout << arr[row][column] << "";
}
