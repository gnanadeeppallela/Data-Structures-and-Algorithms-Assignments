#ifndef SORTEDLIST_H_
#define SORTEDLIST_H_

#include <list>
#include <iterator>
#include "Node.h"

using namespace std;

/***** Modify this file if necessary. *****/

/**
 * A sorted linked list of Node objects.
 */
class SortedList
{
public:
    SortedList();
    virtual ~SortedList();

    int size() const;
    bool check();
list<Node> get_list()const;
    void prepend(const long value);
    void append(const long value);
    void remove(const int index);
    void insert(const long value);
    Node at(const int index);
bool operator >(const Node& other);
private:
    list<Node> data;
};

#endif /* SORTEDLIST_H_ */
