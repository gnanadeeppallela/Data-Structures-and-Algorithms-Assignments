#include <iostream>
#include <iterator>
#include "SortedList.h"
#include <list>
using namespace std;

/**
 * Defaut constructor.
 * Reset the global Node counters.
 */
SortedList::SortedList()
{
    Node::reset();
}

/**
 * Destructor.
 * Reset the global Node counters.
 */
SortedList::~SortedList()
{
    Node::reset();
}
list<Node> SortedList::get_list() const {return data;}
/**
 * @return the size of the data list.
 */
int SortedList::size() const { return data.size(); }

/**
 * Check that the data is sorted.
 * @return true if sorted, false if not.
 */
bool SortedList::check()
{
    if (data.size() == 0) return true;

    list<Node>::iterator it = data.begin();
    list<Node>::iterator prev = it;

    it++;

    // Ensure that each node is greater than the previous node.
    while ((it != data.end()) && (*it > *prev))
    {
        prev = it;
        it++;
    }
    return it == data.end();  // Good if reached the end.
}

/**
 * Insert a new node at the beginning of the data list.
 * @param value the new node's value.
 */

 void SortedList::prepend(const long value)
{
    /***** Complete this function. *****/
    Node va(value);
    data.push_front(va);
}


/**
 * Append a new node at the end of the data list.
 * @param value the new node's value.
 */
void SortedList::append(const long value)
{
    Node va(value);
    data.push_back(va);
	/***** Complete this function. *****/
}

/**
 * Remove a node.
 * @param index the index of the node to remove.
 */
void SortedList::remove(const int index)
{
    /***** Complete this function. *****/
    std::list<Node>::iterator it1=data.begin();
	advance(it1,index);
	data.erase(it1); 
}

/**
 * Insert a new node into the data list at the
 * appropriate position to keep the list sorted.
 */
void SortedList::insert(const long value)
{
    /***** Complete this function. *****/
   
}		
	
	
 

/**
 * Return the data node at the indexed position.
 * @param the index of the node.
 * @return a copy of the data node.
 */
Node SortedList::at(const int index)
{
    /***** Complete this function. *****/
    std::list<Node>::iterator it1=data.begin();
	advance(it1,index);
	return *it1;
}

#include "SortedList.h"