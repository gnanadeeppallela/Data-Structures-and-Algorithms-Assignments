#include<iostream>
using namespace std;

const int MAX_SIZE = 101;  // maximum size of the square matrix
const int MAX_START = 50;   // maximum starting number

/***** Complete this program. *****/

void do_spiral(const int n, const int start);
int make_spiral(int arr[MAX_SIZE][MAX_SIZE], int n, int start);
int print_spiral(int arr[MAX_SIZE][MAX_SIZE], int row, int column, int n);
/**
 * The main: Generate and print spirals of various sizes.
 */
int main()
{
	do_spiral(1, 1);
	do_spiral(5, 1);
	do_spiral(9, 11);
	do_spiral(12, 13);
	do_spiral(15, 17);

}

//The function to obtain size and start values
void do_spiral(const int n, const int start)
{
	int arr[MAX_SIZE][MAX_SIZE];
	cout << "Spiral of size " << n << " starting at " << start << endl;

	//the size is odd
	if (n % 2 != 0)
	{
		cout << endl;
		make_spiral(arr, n, start);
		for (int row = 0; row < n; row++)
		{
			for (int column = 0; column < n; column++)
			{
				print_spiral(arr, row, column, n);
				if (column == n - 1)
					cout << endl;
			}
		}
	}
	//the size is even
	else
	{
		cout << "***** Error: Size " << n << " must be odd." << endl;
	}
	cout << endl;
}

//the function create the spiral
int make_spiral(int arr[MAX_SIZE][MAX_SIZE], int n, int start)
{
	int l = start - 1 + n * n, times = n;
	int row, column, i = 0;
	//cout << l;

	//the size is greater than 1
	if (n > 1)
	{
		while (n > 0)
		{
			//bottom row
			row = n - 1;
			for (int column = n - 1; column >= i; column--)
			{
				arr[row][column] = l--;
			}

			//left column
			column = i;
			for (int row = n - 2; row >= i; row--)
			{
				arr[row][column] = l--;
			}

			//top row
			row = i;
			for (int column = i + 1; column <= n - 1; column++)
			{
				arr[row][column] = l--;
			}

			//right column
			column = n - 1;
			for (int row = i + 1; row <= n - 2; row++)
			{
				arr[row][column] = l--;
			}
			n--;
			i++;
		}

	}
	//size is 1
	else
		arr[n - 1][n - 1] = 1;
}

//print the number with tab
int print_spiral(int arr[MAX_SIZE][MAX_SIZE], int row, int column, int n)
{
	cout << arr[row][column] << "\t";
}
