#include <iostream>
#include <cstdlib>
#include <string.h>
#include <cctype> 
#include <stdio.h>
#include <fstream>
#include <string>
#include <stdlib.h> 
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

class Rational
{
public:
	Rational(int a, int b);
	Rational(int a);
	Rational();

	int get_a()  const {
		return a;
	}
	int get_b() const {
		return b;
	}

	friend Rational operator +(const Rational& r1, const Rational& r2);
	friend Rational operator -(const Rational& r1, const Rational& r2);
	friend Rational operator *(const Rational& r1, const Rational& r2);
	friend Rational operator /(const Rational& r1, const Rational& r2);

	friend ostream& operator <<(ostream& outs, const Rational& r);
	friend istream& operator >> (istream& outs, Rational& r);

private:
	int a, b;  // numerator and denominator



};


Rational::Rational()
{
	a = 0;
	b = 0;
	// Default constructor with an empty body
}

Rational::Rational(int pa, int pb)
{
	a = pa;

	b = pb;

	// Empty body
}
Rational::Rational(int a)
{
	a = a;
	b = 1;
	// Empty body
}

const string INPUT_FILE_NAME = "rational1.txt";

void do_problem(const Rational r1, const Rational r2, const char op);
Rational evaluate(Rational r1, Rational r2, char op);
string simplify(int a, int b);
std::vector<std::string> parse(string line, string delim);

int main()
{
	// Open the input file.
	ifstream input;
	string strg1;
	input.open("rational.in");
	if (input.fail())
	{
		cout << "Failed to open " << INPUT_FILE_NAME << endl;
		return -1;
	}

	Rational r1, r2, R1, R2;
	char op;

	do
	{
		int size;
		getline(input, strg1);
		std::vector<std::string> l_aOutput = parse(strg1," ()()");

		
		std::vector<string>::iterator itAdd, itSub, itMul, itDiv;

		itAdd = std::find(l_aOutput.begin(), l_aOutput.end(), "+");
		itSub = std::find(l_aOutput.begin(), l_aOutput.end(), "-");
		itMul = std::find(l_aOutput.begin(), l_aOutput.end(), "*");
		itDiv = std::find(l_aOutput.begin(), l_aOutput.end(), "/");

		int posOfOp = -1;
		int posOfFirstLeftParen = -1;
		int posOfFirstRightParen = -1;
		char leftParen = '(';
		char rightParen = ')';
		int l_iWNum;
		int l_iNumerator;
		int l_iDenominator;
		auto index=0;

		if (itAdd != l_aOutput.end())
		{
			op = '+';
			index = std::distance(l_aOutput.begin(), itAdd);
		}
		else if (itSub != l_aOutput.end())
		{
			op = '-';
			index = std::distance(l_aOutput.begin(), itSub);
		}
		else if (itMul != l_aOutput.end())
		{
			op = '*';
			index = std::distance(l_aOutput.begin(), itMul);
		}
		else if (itDiv != l_aOutput.end())
		{
			op = '/';
			index = std::distance(l_aOutput.begin(), itDiv);
		}

			//Get values upto this index
			l_iWNum = 1;
			l_iNumerator = 1;
			l_iDenominator = 1;
			for (int i = 0; i < index; i++)
			{
				int divPos = l_aOutput[i].find('/');
				if(divPos > 0)
				{
					//rational number a/b
					vector<string> temp = parse(l_aOutput[i], "/");
					l_iNumerator = stoi(temp[0], nullptr, 10);
					l_iDenominator = stoi(temp[1], nullptr, 10);
				}
				else
				{
					//whole fraction
					l_iWNum = stoi(l_aOutput[i], nullptr,10);
				}
			}

			if (l_iWNum > 1)
			{
				if (l_iNumerator == 1 && l_iDenominator == 1)
					l_iNumerator = l_iWNum;
				else
					l_iNumerator = l_iWNum*l_iDenominator + l_iNumerator;
			}
			if (l_iWNum == 0) {
				l_iDenominator = 1;
				l_iNumerator = 0;
			}
						
			Rational r1(l_iNumerator, l_iDenominator);
			l_iWNum = 1;
			l_iNumerator = 1;
			l_iDenominator = 1;
			for (int i = index+1; i < l_aOutput.size()-1; i++)
			{
				int divPos = l_aOutput[i].find('/');
				if (divPos > 0)
				{
					//rational number a/b
					vector<string> temp = parse(l_aOutput[i], "/");
					l_iNumerator = stoi(temp[0], nullptr, 10);
					l_iDenominator = stoi(temp[1], nullptr, 10);
				}
				else
				{
					//whole fraction
					l_iWNum = stoi(l_aOutput[i], nullptr, 10);
				}
			}

			if (l_iWNum > 1)
			{
				if (l_iNumerator == 1 && l_iDenominator == 1)
					l_iNumerator = l_iWNum;
				else
					l_iNumerator = l_iWNum*l_iDenominator + l_iNumerator;
			}
			if (l_iWNum == 0) {
				l_iDenominator = 1;
				l_iNumerator = 0;
			}
				Rational r2( l_iNumerator, l_iDenominator);

			do_problem(r1, r2, op);
			cout << endl;
		
		


		//cout<<endl;

		//cout<<r1<r2;
		//input >> r1 >> op >> r2;

		//do_problem(r1, r2, op);


	} while (!input.eof());

	cout << endl << "Done!" << endl;
	return 0;
}

std::vector<std::string> parse(string str, string delim)
{
	std::vector<std::string> l_aOutput = std::vector<std::string>();
	/*auto end = str.cend();
	auto start = end;

	std::vector<std::string> v;
	for (auto it = str.cbegin(); it != end; ++it) {
		if (*it != c) {
			if (start == end)
				start = it;
			continue;
		}
		if (start != end) {
			l_aOutput.emplace_back(start, it);
			start = end;
		}
	}
	if (start != end)
		l_aOutput.emplace_back(start, end);*/
	std::size_t prev_pos = 0, pos;
	
	//while ((pos = str.find_first_of("+-", prev_pos)) != std::string::npos)
		while ((pos = str.find_first_of(delim, prev_pos)) != std::string::npos)
	{
		if (pos > prev_pos)
			l_aOutput.push_back(str.substr(prev_pos, pos - prev_pos));
		prev_pos = pos + 1;
	}
	if (prev_pos< str.length())
		l_aOutput.push_back(str.substr(prev_pos, std::string::npos));


	return l_aOutput;

}
void do_problem(const Rational r1, const Rational r2, const char op)
{
	Rational result = evaluate(r1, r2, op);
	//cout << "in do_problem";
	// cout << r1.get_a() << "/"<< r1.get_b() << " " << op << " " << r2.get_a() << "/"<< r2.get_b()  << " = " << result.get_a() << "/"<< result.get_b() << endl;

	cout << simplify(r1.get_a(), r1.get_b()) << " " << op << " " << simplify(r2.get_a(), r2.get_b()) << " = " << simplify(result.get_a(), result.get_b());
}

Rational evaluate(Rational r1, Rational r2, char op)
{
	if (op == '+')
	{
		Rational res = r1 + r2;
		return res;
	}
	else if (op == '-')
	{
		Rational res = r1 - r2;
		return res;
	}
	else if (op == '*')
	{
		Rational res = r1*r2;
		return res;
	}
	else if (op == '/')
	{
		Rational res = r1 / r2;
		return res;
	}
}

string simplify(int a, int b)
{
	std::string str;
	char * res;
	char abuffer[33];
	char bbuffer[33];
	if (a == 0 || b == 0)
		return "0";
	else if (a<b)
	{

		//gcd
		/*
		int g1=a,g2=b;
		while(g1 != g2)
		{
		if(g1 > g2)
		g1 -= g2;
		else
		g2 -= g1;
		}

		if(g1>1)
		{
		a=a/g1;
		b=b/g1;
		}
		else
		{
		a=a;
		b=b;
		}
		*/

		//to_string(a, abuffer, 10);
		//cout<<abuffer;
		str.append("(");
		str.append(to_string(a));
		str.append("/");
		//itoa(b, bbuffer, 10);
		str.append(to_string(b));
		str.append(")");

		// cout<<bbuffer;

		//res = strcat(res, bbuffer);

	}

	else
	{
		char cbuffer[33];
		int t1 = a / b;
		int t2 = a%b;
		//itoa(t2, abuffer, 10);
		/*
		//gcd
		int g1=a,g2=b;
		if(g1 > g2)
		g1 -= g2;
		else
		g2 -= g1;


		if(g1>1)
		{
		a=a/g1;
		b=b/g1;
		}
		else
		{
		a=a;
		b=b;
		}
		*/


		//itoa(t1, cbuffer, 10);
		//	string tempstr(abuffer);
		str.append(to_string(t1));
		str.append("(");
		str.append(to_string(t2));     //string str(arr);                  // "Writing "
		//itoa(b, bbuffer, 10);

		str.append("/");
		str.append(to_string(b));
		str.append(")");

		//res=strcat(res,bbuffer); 
		//	res = strcat(res,")");

		//res = strcat(cbuffer,res);		
	}

	return str;
}

/***** Complete this class. *****/
Rational operator +(const Rational& r1, const Rational& r2)
{
	//
	int d = r1.b*r2.b;
	int n = r1.a*r2.b + r2.a*r1.b;

	Rational result(n, d);
	return result;

}

Rational operator -(const Rational& r1, const Rational& r2)
{
	int d = r1.b*r2.b;
	int n = r1.a*r2.b - r2.a*r1.b;

	Rational result(n, d);
	return result;
}

Rational operator *(const Rational& r1, const Rational& r2)
{
	int d = r1.b*r2.b;
	int n = r1.a*r2.a;

	Rational result(n, d);
	return result;
}

Rational operator /(const Rational& r1, const Rational& r2)
{
	int d = r1.b*r2.a;
	int n = r1.a*r2.b;

	Rational result(n, d);
	return result;
}

ostream& operator <<(ostream& outs, const Rational& r)
{
	// outs << r.a << "/" << r.b ;
	return outs;
}

istream& operator >> (istream& outs, Rational& r)
{
	//outs >> r.a >> r.b;
	return outs;
}
