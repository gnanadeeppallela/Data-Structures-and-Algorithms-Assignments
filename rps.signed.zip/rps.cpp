/* Name: Gnana Deep Pallela
 * Student Id: 011822369
 */
#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

const int MAX_ROUNDS = 20;  // max rounds per game

enum Player { HUMAN, COMPUTER, TIE };
// players and winners
enum Thing { ROCK, PAPER, SCISSORS };
// what each player chooses

char humanChoice();

int compChoice();

string finalWinner(char H, int c);

void record_win(string round_win, int human_wins, int computer_wins, int ties);

/**
 * The main. Play a game consisting of MAX_ROUNDS.
 * Print the number of human player wins, computer wins, and ties.
 */
int main() 
{
	srand(time(NULL)); //seed the random number generator

	int human_wins = 0;
	int computer_wins = 0;
	int ties = 0;
	int number = 1;

	while (number <= MAX_ROUNDS)
	{
		cout << "Round " << number << endl;
		char Hchoice = ' ';
		while (Hchoice == ' ')
		{
			cout << "your choice? ";
			Hchoice = humanChoice();

			//The human choice is printed
			switch (Hchoice)
			{
			case 'r':
			case 'R':
				cout << "you chose ROCK.";
				break;
			case 'p':
			case 'P':
				cout << "you chose PAPER.";
				break;
			case 's':
			case 'S':
				cout << "you chose SCISSORS.";
				break;

			default:
				cout << "*** ERROR: Valid choices are R, P, or S" << endl;
				Hchoice = ' ';
				break;
			}
		}
		cout << endl;

		cout << "The computer chose ";

		int cChoice = compChoice();

		//The computer choice is printed
		if (cChoice == 1)
		{
			cout << "ROCK.";
		}
		else if (cChoice == 2)
		{
			cout << "PAPER.";
		}
		else if (cChoice == 3)
		{
			cout << "SCISSORS.";
		}
		cout << endl;

		string round_win = finalWinner(Hchoice, cChoice);

		//The counter is incremented
		if (round_win == "5")
		{
			//cout << endl;
			human_wins++;
		}
		else if (round_win == "6")
		{
			//cout << endl;
			computer_wins++;
		}
		else if (round_win == "-1")
		{
			//cout << endl;
			ties++;
		}
		number++;

		record_win(round_win, human_wins, computer_wins, ties);
	}
	return 0;
}

//Human gives the input
char humanChoice()
{
	char userChoice;
	cin >> userChoice;
	cout << userChoice << endl;

	return userChoice;
}

//Computer generates a random number
int compChoice()
{
	int randomNo = (rand() % 10) + 1;
	if (randomNo <= 3)
		return 1;
	else if (randomNo > 3 && randomNo <= 6)
		return 2;
	else
		return 3;

}

//The winner of the each round is calculated
string finalWinner(char Hchoice, int cChoice)
{

	if ((Hchoice == 'R' || Hchoice == 'r') && cChoice == 3)
		return "5";

	else if ((Hchoice == 'S' || Hchoice == 's') && cChoice == 1)
		return "6";

	if ((Hchoice == 'P' || Hchoice == 'p') && cChoice == 1)
		return "5";

	else if ((Hchoice == 'R' || Hchoice == 'r') && cChoice == 2)
		return "6";

	if ((Hchoice == 'S' || Hchoice == 's') && cChoice == 2)
		return "5";

	else if ((Hchoice == 'P' || Hchoice == 'p') && cChoice == 3)
		return "6";

	else
		return "-1";
}

//Final score is printed
void record_win(string round_win, int human_wins, int computer_wins, int ties)
{
	int number;
	human_wins = human_wins - 1;

	//The output is printed
	if (round_win == "5")
	{
		cout << "The winner is you.";
		cout << endl;
		human_wins++;
	}
	else if (round_win == "6")
	{
		cout << "The winner is the computer.";
		cout << endl;
		computer_wins++;
	}
	else if (round_win == "-1")
	{
		cout << "tie.";
		cout << endl;
		ties++;
	}
	cout << endl;
	number = human_wins + computer_wins + ties;

	//The rounds end when the maximum value is reached
	if (number == MAX_ROUNDS)
	{
		cout << "Summary" << endl;
		cout << "-------" << endl;
		cout << "   Human wins: ";
		cout << human_wins << endl;
		cout << "Computer wins: ";
		cout << computer_wins << endl;
		cout << "         Ties: ";
		cout << ties << endl;
	}
}
