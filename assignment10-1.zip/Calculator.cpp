//Calculator.h
#include "Calculator.h"

// term handles for * and / operators
void Calculator::term(vector<string>& v) 
{
	string str;
	string op;
	std::vector<std::string> l_aOutput = std::vector<std::string>();

	std::size_t prev_pos = 0, pos;
	
	if (op=="*")
	{
		l_aOutput.push_back(str.substr(prev_pos, std::string::npos));
		factor(v);
	}
	if (op=="/")
	{
		l_aOutput.push_back(str.substr(prev_pos, std::string::npos));
		factor(v);
	}		
}

// Expression handles for + and - operators
void Calculator::expression(vector<string>& v) 
{
	string str;
	string op;
	std::vector<std::string> l_aOutput = std::vector<std::string>();

	std::size_t prev_pos = 0, pos;

	if (op == "+")
	{
		l_aOutput.push_back(str.substr(prev_pos, pos - prev_pos));
		prev_pos = pos + 1;
		factor(v);
	}
	if (op == "-")
	{
		l_aOutput.push_back(str.substr(prev_pos, pos - prev_pos));
		prev_pos = pos + 1;
		factor(v);
	}	
}
//Function handles numbers
void Calculator::factor(vector<string>& v) 
{
	string str;
	string op;
	
	std::vector<std::string> l_aOutput = std::vector<std::string>();

	std::size_t prev_pos = 0, pos;
	
	if (op =="(")
		l_aOutput.push_back(str.substr(prev_pos, pos - prev_pos));
		prev_pos = pos + 1;
	
	if (op ==")")
		l_aOutput.push_back(str.substr(prev_pos, std::string::npos));
		
	factor(v);
}

Calculator operator +(const Calculator& r1, const Calculator& r2) 
{
	int d = r1.b;
	int n = r1.a;
	Calculator result(n, d);
	return result;

}

Calculator operator -(const Calculator& r1, const Calculator& r2) 
{
	int d = r1.b;
	int n = r1.a;
	Calculator result(n, d);
	return result;
}
Calculator::Calculator() {}
Calculator::Calculator(int pa, int pb) {}
Calculator::Calculator(int a) {}
Calculator operator *(const Calculator& r1, const Calculator& r2) 
{
	int d = r1.b;
	int n = r1.a;
	Calculator result(n, d);
	return result;
}

Calculator operator /(const Calculator& r1, const Calculator& r2) 
{
	int d = r1.b;
	int n = r1.a;
	Calculator result(n, d);
	return result;
}


