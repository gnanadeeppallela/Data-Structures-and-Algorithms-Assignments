//		Calculator.h
#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <iostream>
#include <cstdlib>
#include <string.h>
#include <cctype> 
#include <stdio.h>
#include <fstream>

#include <string>
#include <stdlib.h> 
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;
class Calculator 
{
public:
	
	void factor(vector<string>& v);
	void term(vector<string>& v);
	void expression(vector<string>& v);
	
	Calculator(int a, int b);
	Calculator(int a);
	Calculator();

	friend Calculator operator +(const Calculator& r1, const Calculator& r2);
	friend Calculator operator -(const Calculator& r1, const Calculator& r2);
	friend Calculator operator *(const Calculator& r1, const Calculator& r2);
	friend Calculator operator /(const Calculator& r1, const Calculator& r2);
	int a, b;
};

#endif

