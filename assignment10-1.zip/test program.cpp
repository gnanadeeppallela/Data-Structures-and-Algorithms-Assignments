//main Program
#include <iostream>
#include <cstdlib>
#include <string.h>
#include <cctype> 
#include <stdio.h>
#include <fstream>
#include <string>
#include <stdlib.h> 
#include <sstream>
#include <vector>
#include <algorithm>
#include "Calculator.h"

using namespace std;

void factor(vector<string>& v);
void term(vector<string>& v);
void expression(vector<string>& v);
std::vector<std::string> parse(string str, string delim);
int main() 
{
	while (1) 
	{
		//Enter input string
		string strg1 = "";
		cout << "Expression? ";
		getline(cin, strg1);
		int size;
		char op;
		std::vector<std::string> l_aOutput = parse(strg1, " ()()");

		std::vector<string>::iterator itAdd, itSub, itMul, itDiv;

		itAdd = std::find(l_aOutput.begin(), l_aOutput.end(), "+");
		itSub = std::find(l_aOutput.begin(), l_aOutput.end(), "-");
		itMul = std::find(l_aOutput.begin(), l_aOutput.end(), "*");
		itDiv = std::find(l_aOutput.begin(), l_aOutput.end(), "/");

		int posOfOp = -1;
		int posOfFirstLeftParen = -1;
		int posOfFirstRightParen = -1;
		char leftParen = '(';
		char rightParen = ')';
		int l_iWNum;
		int l_iNumerator;
		int l_iDenominator;
		auto index = 0;

		if (itAdd != l_aOutput.end()) 
		{
			op = '+';
			index = std::distance(l_aOutput.begin(), itAdd);
		} 
		else if (itSub != l_aOutput.end()) 
		{
			op = '-';
			index = std::distance(l_aOutput.begin(), itSub);
		} 
		else if (itMul != l_aOutput.end()) 
		{
			op = '*';
			index = std::distance(l_aOutput.begin(), itMul);
		} 
		else if (itDiv != l_aOutput.end()) 
		{
			op = '/';
			index = std::distance(l_aOutput.begin(), itDiv);
		}
		
		//Get values upto this index
		l_iWNum = 1;
		l_iNumerator = 1;
		l_iDenominator = 1;
		for (int i = 0; i < index; i++) 
		{
			int divPos = l_aOutput[i].find('/');
			if (divPos > 0) 
			{
				vector<string> temp = parse(l_aOutput[i], "/");
				l_iNumerator = stoi(temp[0], nullptr, 10);
				l_iDenominator = stoi(temp[1], nullptr, 10);
			} 
			else 
			{
				l_iWNum = stoi(l_aOutput[i], nullptr, 10);
			}
		}

		if (l_iWNum > 1) 
		{
			if (l_iNumerator == 1 && l_iDenominator == 1)
				l_iNumerator = l_iWNum;
			else
				l_iNumerator = l_iWNum * l_iDenominator + l_iNumerator;
		}
		if (l_iWNum == 0) 
		{
			l_iDenominator = 1;
			l_iNumerator = 0;
		}

		Calculator r1(l_iNumerator, l_iDenominator);
		l_iWNum = 1;
		l_iNumerator = 1;
		l_iDenominator = 1;
		for (int i = index + 1; i < l_aOutput.size() - 1; i++) 
		{
			int divPos = l_aOutput[i].find('/');
			if (divPos > 0) 
			{
				vector<string> temp = parse(l_aOutput[i], "/");
				l_iNumerator = stoi(temp[0], nullptr, 10);
				l_iDenominator = stoi(temp[1], nullptr, 10);
			} 
			else 
			{
				l_iWNum = stoi(l_aOutput[i], nullptr, 10);
			}
		}
		if (l_iWNum > 1) 
		{
			if (l_iNumerator == 1 && l_iDenominator == 1)
				l_iNumerator = l_iWNum;
			else
				l_iNumerator = l_iWNum * l_iDenominator + l_iNumerator;
		}
		if (l_iWNum == 0) 
		{
			l_iDenominator = 1;
			l_iNumerator = 0;
		}
		Calculator r2(l_iNumerator, l_iDenominator);

		cout << endl;
		//End the loop when . is entered
		if(strg1==".")
		{
			cout<<"Done!"<<endl;
			return 0;
		}
	}
	return 0;
}

//The function to parse the string
std::vector<std::string> parse(string str, string delim) 
{
	std::vector<std::string> l_aOutput = std::vector<std::string>();

	std::size_t prev_pos = 0, pos;

	while ((pos = str.find_first_of(delim, prev_pos)) != std::string::npos) 
	{
		if (pos > prev_pos)
			l_aOutput.push_back(str.substr(prev_pos, pos - prev_pos));
		prev_pos = pos + 1;
	}
	if (prev_pos < str.length())
		l_aOutput.push_back(str.substr(prev_pos, std::string::npos));
}
