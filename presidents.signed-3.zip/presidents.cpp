/*
 Name : Gnana Deep Pallela
 Student Id: 011822369
 */
#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <stdlib.h>
#include <iomanip>

using namespace std;

const string INPUT_FILE_NAME = "presidents.in";

/*
 *  The main: Reading the input file and printing the report.
 */
int z,x=0;
float avg;
int main()
{
    // Open the input file.
    ifstream input;
    string strg;
    input.open(INPUT_FILE_NAME);

    cout << "First name  Middle name Last name   Born  Died Age Start End  Party"<<endl;
    cout << "----------  ----------- ---------   ----  ---- --- ----- ---- -----"<<endl;

    while (!input.eof()) //loop until the end of the file
    {
        getline (input,strg);
        if(strg == ".")
        	break;

        //Name: sub string
        size_t position1=0;
        position1= strg.find(" (");
        string names= strg.substr(0,position1);

        size_t firstPos = names.find(" ");
        string  firstName =  names.substr(0,firstPos);
        string firstNamefinal = firstName + "            ";
        cout << firstNamefinal.substr(0,11)<<" ";  //Printing the First name

        string  remName = names.substr(firstPos+1);
        size_t  middlePos = 0;
        if((middlePos = remName.find(" "))!=string::npos)
        {
        	string middleName = remName.substr(0,middlePos);
        	size_t middleRemPos=0;
        	string middleRemName = remName.substr(middlePos+1);
        	if((middleRemPos = middleRemName.find(" "))!=string::npos)
        	{
        	     middleName = middleName+" "+middleRemName.substr(0,middleRemPos);

        	}
        	string middleNamefinal = middleName + "            ";
        	cout<<middleNamefinal.substr(0,11)<<" ";  //Printing the middle name

        	string lastName = middleRemName.substr(middleRemPos+1);
        	string lastNamefinal = lastName + "           ";
        	cout<<lastNamefinal.substr(0,10)<<" ";    //Printing the last name if middle name is present
        }
        else
        {
        	cout<<"           "<<" ";
        	string lastName = remName;
        	string lastNamefinal = lastName + "          ";
        	cout<<lastNamefinal.substr(0,10)<<" ";    //Printing the last name if middle term is absent
        }

        //Period of life : substring
        string temp1 = strg.substr(position1+1);
        int position2 = temp1.find(" )");
        string dates = temp1.substr(2,position2-2);

        //date of birth
        size_t position8= temp1.find(" ");
        string dob = temp1.substr(position8,5);
        string dobfinal = dob + "    ";
        cout<<dobfinal.substr(0,5)<<" ";

        //date of death
        size_t position9=temp1.find(" )");
        if(temp1.substr(position8,position9).find("-") != string::npos)
        {
        	string dod = temp1.substr((position9)-5,5);
            cout << dod;
            z++;

            //Calculating the age
            int i = atoi( dob.c_str() );
            int j = atoi( dod.c_str() );
            int age=j-i;
            cout<<" "<<age<<" ";

            //Calculating the average
            avg=age+x;
            x=avg;
        }
        else
        {
        	int age;
        	cout<<"         ";   //Spacing if the President is alive
        }

        //Party name and the duration: substring
        if(size_t position6= strg.find(") "))
        {
        	string temp = strg.substr((position6)+2);

        	//begin of term
        	size_t position8= temp.find(" ");
        	string startterm = temp.substr(position8+1,4);
        	cout <<" "<<startterm;

        	//end of term
        	size_t position9= temp.find("- ");
        	if(temp.find("- ")!=string::npos)
        	{
        		string endterm = temp.substr(position9+1,5);
        		cout <<" "<<endterm;
        	}
        	else
        	{
        	 	cout <<"  "<<startterm; //printing: if the term is 1 year
        	}

        	//party
        	size_t position7 = temp.find(" ");
        	string party= strg.substr((position6)+1,position7+1);
        	cout <<party;
        }
            cout <<endl;
    }
    avg=avg/z;
    cout<<endl;
    cout<<"Average age at death = "<<fixed << setprecision(1)<<avg;  //Printing the average
    return 0;
}
