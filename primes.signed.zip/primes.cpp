#include <iostream>
using namespace std;

const int MAX_NUMBER = 1000;  // maximum possible prime number
const int ROW_SIZE = 20;    // row size for printing

int compute_primes(int arr[]);
int print_primes(int arr[]);

/**
 * The main: Compute and print the prime numbers up to MAX_NUMBER.
 */

int main()
{
	int arr[MAX_NUMBER];
	for (int number = 2; number <= MAX_NUMBER; number++)
	{
		arr[number] = number;
	}
	compute_primes(arr);
}

//The function to compute the prime numbers
int compute_primes(int arr[])
{
	//loop to identify the next prime number
	for (int prime = 2; prime <= MAX_NUMBER; prime++)
	{
		if (arr[prime] != 1)
		{
			//loop to mark the composite numbers as 1
			for (int multiple = 2; (multiple * prime) <= MAX_NUMBER; multiple++)
			{
				arr[prime * multiple] = 1;
			}
		}
	}
	print_primes(arr);
}

//The function to print the prime numbers in rows
int print_primes(int arr[])
{
	int count = 0;
	for (int number = 2; number <= MAX_NUMBER; number++)
	{
		//count is increment
		if (arr[number] != 1)
		{
			count++;
			cout << arr[number] << "\t";

			//New line when the count is multiple of 20
			if (count % ROW_SIZE == 0)
				cout << "\n";
		}

	}
	cout <<endl<<endl<< "Done!";
}

