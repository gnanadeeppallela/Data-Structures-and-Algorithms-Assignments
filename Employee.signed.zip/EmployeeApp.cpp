#include "Employee.h"
#include <iostream>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <string>
#include <cctype>
#include <sstream>

using namespace std;

enum ERROR_CODE {NO_ERROR, DUPLICATE, NOT_FOUND, INVALID_COMMAND};
Employee execute(const char command, const Employee record,vector<Employee>& list);
Employee print_all(const char command, const Employee record,vector<Employee>& list);
Employee print_stats(const char command, const Employee record,vector<Employee>& list);
const string INPUT_FILE_NAME = "commands.in";
string last;
string first;

int main() 
{
	// Open the input file.
	ifstream input;
	string strg, strg1 = "", strg2, strg3;
	input.open(INPUT_FILE_NAME);
	if (input.fail()) 
	{
		cout << "Failed to open " << INPUT_FILE_NAME << endl;
		return -1;
	}

	char command;
	int id;
	string last;
	string first;
	double salary;
	
	vector<Employee> list;
	
	while (!input.eof()) 
	{
		int j = 0;
		
		//Commmand
		strg1 = "";
		getline(input, strg);
		command = strg[0];

		//ID
		for (int i = 2; i < 5; i++)
			strg1 += strg[i];

		stringstream convert(strg1); //object from the class stringstream
		convert >> id;
		if (strg.find(',') != string::npos) 
		{
			//last name
			strg1 = "";
			int pos = strg.find(",");
			strg.erase(0, pos + 1);

			int pos1 = strg.find(",");
			for (int i = 0; i < pos1; i++)
				strg1 += strg[i];

			last = strg1;

			strg1 = "";
			
			//First name
			int posF = strg.find(",");
			strg.erase(0, posF + 1);
			int posF1 = strg.find(",");
			for (int i = 0; i < posF1; i++)
				strg1 += strg[i];
			first = strg1;  
		}
		
		//salary
		int posF2 = strg.find(",");
		strg.erase(0, posF2 + 1);
		strg1 = "";
		int pos2 = strg.find_last_of(",");
		for (int i = 0; i <= 5; i++)
			strg1 += strg[i];
			
		//object from the class stringstream
		stringstream convert1(strg1);		
		convert1 >> salary;
		// cout<<salary<<endl;
		
		//if command = +
		if (command == '+') 
		{
			Employee record(id, last, first, salary);
			if (list.size() > 0) 
			{

				for (int i = 0; i < list.size(); i++) 
				{
					if (list[i].id == id) 
					{
						j++;
					}
				}
			}
			//pushback if the id is not repated
			if (j == 0)
				list.push_back(record);
			execute(command, record, list);

		} 
		//if the command is not the + operator
		else 
		{
			last = "";
			first = "";

			Employee record(id, last, first, salary);

			execute(command, record, list);

		}
	}
	cout << endl;
	Employee record(id, last, first, salary);
	
	//to sort the id in ascending order
	print_all(command, record, list);
	
	//to print the maximum, minimum and average
	print_stats(command, record, list);
	return 0;
}
Employee print_all(const char command, const Employee record, vector<Employee>& list) 
{
	cout << "All employees" << endl;
	cout << "-------------" << endl;
	
	//sort the objects according to their id's
	for (int i = 0; i < list.size(); i++)
		for (int j = i; j < list.size(); j++)
			if (list[i].id > list[j].id)
				swap(list[i], list[j]);
	for (int i = 0; i < list.size(); i++)
		cout << list[i];
	return record;
}
Employee print_stats(const char command, const Employee record, vector<Employee>& list) 
{
	double avg = 0;
	int min = list[0].salary;
	int max = list[0].salary;
	
	//to find the min and max
	for (int i = 0; i < list.size(); i++) 
	{
		if (list[i].salary > max) 
		{
			max = list[i].salary;
		}
		else if (list[i].salary < min) 
		{
			min = list[i].salary;
		}
	}
	//to find the average
	for (int i = 0; i < list.size(); i++)
		avg = (avg + list[i].salary);

	cout << endl;
	cout << "Statistics" << endl;
	cout << "----------" << endl;
	cout << "Minimum salary = $ ";
	cout << min << ".00";
	cout << endl;

	cout << "Maximum salary = $";
	cout << max << ".00";
	cout << endl;

	cout << "Average salary = $";
	cout << avg / list.size() << ".00";
	cout << endl;

	return record;
}
Employee execute(const char command, const Employee record, vector<Employee>& list) 
{
	int q;
	switch (command) 
	{
	//to print the statement as duplicate id when the id is already in the vector
	case '+':
		q = 0;
		if (list.size() > 1) 
		{
			for (int i = 0; i < list.size() - 1; i++) 
			{
				if (list[i].id == record.id) 
				{
					cout << command << " " << record.id << ": "
							<< "*** Duplicate ID ***" << endl;
					q++;
				}

			}
		}
		
		//to call the stream operator to print the record 
		if (q == 0) 
		{
			cout << command;
			cout << " " << record.id << ": " << record;
		}

		//cout<<command;
		//cout<<record;	
		break;

	case '-':
		q = 0;
		if (list.size() > 0) 
		{
			for (int i = 0; i < list.size(); i++) 
			{
				//to remove the object from the vector
				if (list[i].id == record.id) 
				{
					cout << command;

					cout << " " << list[i].id << ": Employee{ID=" << list[i].id << ", last=" << list[i].last << ", first=" << list[i].first << ", salary=" << list[i].salary << "}" << endl;
				
					list.erase(list.begin() + i);

					q++;

				}

			}
		}
		//to print the statement as ID not found when the id is not in the vector
		if (q == 0)
			cout << command << " " << record.id << ": " << "*** ID not found ***" << endl;

		break;

	case '?':
		q = 0;
		if (list.size() > 0) 
		{
			//to print the record which is in the vector
			for (int i = 0; i < list.size(); i++) 
			{
				if (list[i].id == record.id) 
				{		
					cout << command;
					cout << " " << list[i].id << ": Employee{ID=" << list[i].id << ", last=" << list[i].last << ", first=" << list[i].first << ", salary=" << list[i].salary << "}" << endl;
					q++;
				}

			}
		}
		//to print the statement as ID not found when the id is not in the vector
		if (q == 0)
			cout << command << " " << record.id << ": " << "*** ID not found ***" << endl;

		break;
		
	//to print the statement as Invalid command when the command is wrong
	default:
		cout << command << " " << record.id << ": *** Invalid command ***" << endl;
		break;
	}
	return record;
}

