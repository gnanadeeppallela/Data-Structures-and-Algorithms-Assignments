#ifndef EMPLOYEE_H_
#define EMPLOYEE_H_

#include<string>

using namespace std;

class Employee 
{
public:
	// Constructors
	Employee();
	Employee(int i, string l, string f, double s);

	// Destructor
	~Employee();

	void print();

	int id;
	string last, first;
	double salary;

	friend ostream& operator <<(ostream& outs, const Employee& record);
	friend istream& operator >>(istream& ins, Employee& record);
};

#endif
