#include "Employee.h"
#include <string.h>
#include <string>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <string>
#include <cctype>
#include <sstream>

using namespace std;

//constructor
Employee::Employee() :id(0), last(""), first(""), salary(0) 
{

}
//constructor
Employee::Employee(int i, string l, string f, double s) :id(i), last(l), first(f), salary(s) 
{

}
//Destructor
Employee::~Employee() 
{

}

//print output
void Employee::print()
{
cout << id << "/" << last << "/" << first << "/" << salary << endl;
}

//output
ostream& operator <<(ostream& outs, const Employee& record) 
{
	outs << "Employee{ID=" << record.id << ", last=" << record.last << ", first=" << record.first << ", salary=" << record.salary << "}" << endl;
	return outs;
}
//input
istream& operator >>(istream& ins, Employee& record)
{
	return ins;
}

