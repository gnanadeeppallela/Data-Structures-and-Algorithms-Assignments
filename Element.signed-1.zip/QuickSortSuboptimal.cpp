#include "QuickSortSuboptimal.h"

/**
 * Constructor.
 * @param name the name of this algorithm.
 */
QuickSortSuboptimal::QuickSortSuboptimal(string name) : QuickSorter(name) {}

/**
 * Destructor.
 */
QuickSortSuboptimal::~QuickSortSuboptimal() {}

/**
 * Choose a bad pivot, always the leftmost element of the subrange.
 * @param left the left index of the subrange to sort.
 * @param right the right index of the subrange to sort.
 * @return the chosen pivot value.
 */
Element& QuickSortSuboptimal::choose_pivot_strategy(const int left, const int right)
{
   /***** Complete this member function. *****/
    //reference: http://www.algolist.net/Algorithms/Sorting/Quicksort
    int i=left,j=right;
      Element tmp;
      Element pivot = data[left];
 
      /* partition */
      while (i <= j) {
      	  compare_count++;
            while (data[i] < pivot)
                  i++;
            while (data[j] > pivot)
                  j--;
            if (i <= j) {
                  tmp = data[i];
                  data[i] = data[j];
                  data[j] = tmp;
                  i++;
                  j--;
            }
      };
 
      /* recursion */
      if (left < j)
            choose_pivot_strategy(left, j);
      if (i < right)
            choose_pivot_strategy(i, right);
}
