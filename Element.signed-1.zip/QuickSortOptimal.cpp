#include "QuickSortOptimal.h"

/**
 * Constructor.
 * @param name the name of this algorithm.
 */
QuickSortOptimal::QuickSortOptimal(string name) : QuickSorter(name) {}

/**
 * Destructor.
 */
QuickSortOptimal::~QuickSortOptimal() {}

/**
 * Choose a good pivot, the median-of-three:
 * The middle value of the leftmost, rightmost, and center elements.
 * This is a compromise since the most optimal pivot would be the
 * median of the subrange, but that's too expensive to compute.
 * @param left the left index of the subrange to sort.
 * @param right the right index of the subrange to sort.
 * @return the chosen pivot value.
 */
Element& QuickSortOptimal::choose_pivot_strategy(const int left, const int right)
{

    //reference: http://www.algolist.net/Algorithms/Sorting/Quicksort
    int i=left,j=right;
      Element tmp;
      Element pivot = data[(left + right) / 2];
 
      /* partition */
      while (i <= j) {
      	  compare_count++;
            while (data[i] < pivot)
                  i++;
            while (data[j] > pivot)
                  j--;
            if (i <= j) {
                 tmp = data[i];
                 data[i] = data[j];
                 data[j] = tmp;
                  i++;
                  j--;
            }
      };
 
      /* recursion */
      if (left < j)
            choose_pivot_strategy(left, j);
      if (i < right)
            choose_pivot_strategy(i, right);
}