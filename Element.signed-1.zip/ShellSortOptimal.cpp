#include "ShellSortOptimal.h"

/**
 * Constructor.
 * @param name the name of this algorithm.
 */
ShellSortOptimal::ShellSortOptimal(string name) :VectorSorter(name) {}

/**
 * Destructor.
 */
ShellSortOptimal::~ShellSortOptimal() {}

/**
 * Run the optimal shellsort algorithm.
 * According to Don Knuth:
 * h = 3*i + 1 for i = 0, 1, 2, ... used in reverse.
 * @throws an exception if an error occurred.
 */
 
 //reference:http://stackoverflow.com/questions/5889177/shellsort-gap-question-java

void ShellSortOptimal::run_sort_algorithm() throw (string)
{

    int gap=0;
    while(gap<size/3)
        gap = gap*3+1;

    while(gap>0)
    {
          for (gap = size/2; gap > 0; gap /= 2)
    {

        for (int i = gap; i < size; i++)
        {
        	Element temp=data[i];
            for (int j=i-gap; j>=0 && data[j]>data[j+gap]; j-=gap) {
            	compare_count++;
                temp = data[j];

                data[j] = data[j+gap];

                data[j+gap] = temp;
                move_count++;
            }

            }
    }
        
     
    }
        

}
