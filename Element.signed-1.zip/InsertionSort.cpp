#include "InsertionSort.h"

/**
 * Constructor.
 * @param name the name of the algorithm.
 */
InsertionSort::InsertionSort(string name) : VectorSorter(name) {}

/**
 * Destructor.
 */
InsertionSort::~InsertionSort() {}

/**
 * Run the insertion sort algorithm.
 * @throws an exception if an error occurred.
 */
 
 //Reference: http://quiz.geeksforgeeks.org/insertion-sort/
void InsertionSort::run_sort_algorithm() throw (string)
{
    /***** Complete this member function. *****/

    for (int i = 1; i < size; i++) {
    	Element key=data[i];
        int j = i-1;
        compare_count++;
        while (j >= 0 && data[j]>key) {

            data[j+1] = data[j];
            j--;
        }
        data[j+1]=key;
    }
}
