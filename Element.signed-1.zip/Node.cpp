#include "Node.h"
#include "Element.h"

/***** Complete this class. *****/
Node::Node()
{
}

Node::~Node()
{
}
Node::Node(Element& other)
{
	
}


