#ifndef NODE_H_
#define NODE_H_

#include "Element.h"

/**
 * A node of the linked list for mergesort.
 */
class Node
{
public:
	Node();
	Node(Element& other);
	~Node();
	Node get_value() const;
	Element element;
	Node *next;
	
    /***** Complete this class. *****/
};

#endif /* NODE_H_ */
