#include <math.h>
#include "Node.h"
#include <cstddef>
    /***** Complete this file. *****/
    
/**
 * Convert a coordinate's latitude and longitude
 * into a row and column, respectively, for printing.
 */
 Node::Node()
 {
 	next=nullptr;
 	name="";
 	state="";
 	row=0;
 	col=0;
 	
 }
 Node::Node(Coordinate coordinate)
 {
 	next=nullptr;
 	name="";
 	state="";
 	convert_coordinate(coordinate);
 }
 Node::~Node()
 {
 }
 
 Node::Node(City city)
{
	next=nullptr;
	name=city.name;
	state=city.state;
    convert_coordinate(city.get_coordinate());
}

/**
 * Destructor.
 */

void Node::convert_coordinate(const Coordinate& coordinate)
{
    row = round(2*(Coordinate::MAX_LATITUDE - coordinate.get_latitude()));
    col = round(2*(coordinate.get_longitude() - Coordinate::MIN_LONGITUDE));
    //cout<<row<<" "<<col<<endl;
}

/**
 * Overloaded > operator used to determine
 * where to insert a node into the linked list.
 * The list is sorted first by row and then by column.
 */
bool Node::operator >(const Node &other)
{
    /***** Complete this function. *****/
    if(row>other.row)
    	return 1;
    else
	{
		if(row==other.row)
		{
			if(col>other.col)
			{
			return 1;	
			}	
			else
			return 0;
		}
		return 0;	
	}          
}

//printing the # when the name is absent and * when the name is present
ostream& operator <<(ostream& outs, const Node& node)
{
    if(node.name=="")
    {
		cout << "#";
	}
    else
	{
		cout<<"*"<<node.name<<" "<<node.state;
	}
    return outs;
}
