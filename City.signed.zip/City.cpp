#include "City.h"
#include <stdlib.h>

#include <sstream>
    /***** Complete this file. *****/
    
    City::City()
    {
	}
	City::~City()
    {	
	}
	Coordinate City::get_coordinate() const { return coordinate; }
	//double Coordinate::get_latitude()  const { return latitude; }
//double Coordinate::get_longitude() const { return longitude; }
	
	
istream& operator >>(istream& ins, City& city)
{
	//using getline to seperate 
	string str3,str4;
	getline(ins,city.name,',');
	getline(ins,city.state,',');
	getline(ins,str3,',');
	getline(ins,str4);
	
	//convert string to double
	istringstream buffer(str3);
	city.coordinate.latitude;
	buffer>>city.coordinate.latitude;
	istringstream buffer1(str4);
	city.coordinate.longitude;
	buffer1>>city.coordinate.longitude;
	
	//cout<<city.coordinate.latitude<<" "<<city.coordinate.longitude<<endl;
}
