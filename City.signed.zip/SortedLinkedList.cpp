#include "SortedLinkedList.h"
#include <iostream>
#include <cstddef>
    /***** Complete this file. *****/
    
/**
 * Insert a new node into the sorted linked list.
 * Uses the overloaded Node::operator > to compare nodes.
 * @param node points to the node to insert.
 */
 SortedLinkedList::SortedLinkedList()
 {	
 }
 SortedLinkedList::~SortedLinkedList()
 {	
 }
 //using the code from the slides
void SortedLinkedList::insert(Node *node)
{
	if (head == nullptr)
    {
        head = node;
    }

    else
    {
	if (!(*node > *head))
    {
        node->next = head;
        head = node;
    }
    else
    {
        Node *pointr = head;  
        Node *prev;  
        while ((pointr != nullptr) && (*node > *pointr))
        {
            prev = pointr;
            pointr = pointr->next;
        }
        prev->next = node;
        node->next = pointr;
    }
    }
}

//using the code from the savitch and Internet
ostream& operator <<(ostream& outs, const SortedLinkedList& list)
{
    int r = 0;
    int c = 0;
    Node *Pointr = list.head;
    
    while (Pointr != nullptr)
    {  	
        if (r != Pointr->row)
        {
            c = 0;
            cout << endl; 
            r++;
            while (r < Pointr->row)
			{
                cout << endl; 
                r++;
            } 
        }
        if (c <= Pointr->col)
        {
            while (c < Pointr->col)
            {
                cout << " ";  
                c++;
            }
            cout << *Pointr; 
            c++;
        }
        Pointr = Pointr->next;
    }

    return outs;
}
