#include "Coordinate.h"
#include <stdlib.h>
#include <sstream>
/**
 * Maximum latitude and minimum longitude for this app's input data.
 */
const double Coordinate::MAX_LATITUDE  =   49.373112;
const double Coordinate::MIN_LONGITUDE = -124.769867;

    /***** Complete this file. *****/
    Coordinate::Coordinate()
    {
    	latitude=0;
    	longitude=0;
	}
	Coordinate::~Coordinate()
    {
	}
	
double Coordinate::get_latitude()  const { return latitude; }
double Coordinate::get_longitude() const { return longitude; }

istream& operator >>(istream& ins, Coordinate& coordinate)
{
	//using getline to seperate
	string str1,str2;
	getline(ins,str1,',');
	getline(ins,str2);
	
	//convert the string to double
	istringstream buffer(str1);
	coordinate.latitude;
	buffer>>coordinate.latitude;
	istringstream buffer1(str2);
	coordinate.longitude;
	buffer1>>coordinate.longitude;
}